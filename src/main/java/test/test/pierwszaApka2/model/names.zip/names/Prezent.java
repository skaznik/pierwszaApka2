package test.test.pierwszaApka2.model.names;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Prezent {
    private String nazwa;

}
