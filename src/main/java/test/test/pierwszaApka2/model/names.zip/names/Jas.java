package test.test.pierwszaApka2.model.names;

import org.springframework.stereotype.Component;

@Component("zlosliwiec")
public class Jas extends Dziecko {
}
