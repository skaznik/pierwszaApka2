package test.test.pierwszaApka2.model.names;

import org.springframework.stereotype.Component;

@Component("lobuz")
public class Zbus extends Dziecko {
}
