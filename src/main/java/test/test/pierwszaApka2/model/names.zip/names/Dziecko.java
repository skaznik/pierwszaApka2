package test.test.pierwszaApka2.model.names;

public class Dziecko {

    public void daj(Prezent prezent) {
        System.out.println("Masz prezent : " + prezent.getNazwa());
    }
}
